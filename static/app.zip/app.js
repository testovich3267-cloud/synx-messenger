const API_URL = "http://localhost:8000";
let token = localStorage.getItem("token");

let currentChatId = null;
let ws = null;

let pinnedChats = JSON.parse(localStorage.getItem("pinnedChats") || "[]");

// =========================
// LOAD CHATS
// =========================

async function loadChats() {
    const res = await fetch(API_URL + "/chats", {
        headers: { "Authorization": "Bearer " + token }
    });
    const chats = await res.json();

    chats.sort((a, b) => {
    const ap = pinnedChats.includes(a.id);
    const bp = pinnedChats.includes(b.id);
    return bp - ap; // закреплённые сверху
});

    const list = document.getElementById("chatList");
    list.innerHTML = "";

    chats.forEach(chat => {
        const chatTitle = chat.title || "Без названия";

        const item = document.createElement("div");
        item.className = "chat-item";

        item.innerHTML = `
    <div class="avatar" style="--avatar-color:${generateColorFromName(chatTitle)}">
        ${chatTitle[0].toUpperCase()}
        <div class="avatar-badge">${chat.type === "group" ? "👥" : "👤"}</div>
    </div>
    <div class="chat-main">
        <div class="chat-name-row">
            <div class="chat-name">
    ${chatTitle}
    ${pinnedChats.includes(chat.id) ? '<span class="pin-mark">📌</span>' : ''}
</div>

        </div>
    </div>
`;
        // ВАЖНО: backend отдаёт поле id (атрибут модели), а не Id
        item.onclick = () => openChat(chat.id, chatTitle);
        list.appendChild(item);
    });
}

// =========================
// OPEN CHAT
// =========================

async function openChat(chatId, title) {
    const safeTitle = title || "Без названия";

    currentChatId = chatId;

    const avatar = document.getElementById("chatAvatar");
    avatar.textContent = safeTitle[0].toUpperCase();
    avatar.style.setProperty("--avatar-color", generateColorFromName(safeTitle));

    document.getElementById("chatTitle").textContent = safeTitle;

    await loadMessages(chatId);
    connectWS(chatId);
}

// =========================
// LOAD MESSAGES
// =========================

async function loadMessages(chatId) {
    const res = await fetch(`${API_URL}/chats/${chatId}/messages`, {
        headers: { "Authorization": "Bearer " + token }
    });
    const msgs = await res.json();

    const body = document.getElementById("chatBody");
    body.innerHTML = "";

    msgs.forEach(msg => appendMessage(msg));
}

// =========================
// SEND MESSAGE
// =========================

async function sendMessage(text) {
    text = text?.trim();
    if (!text && !editMessageId && !replyTo) return;

    // ============================
    // 1. РЕДАКТИРОВАНИЕ СООБЩЕНИЯ
    // ============================
    if (editMessageId) {
        await fetch(`http://localhost:8000/messages/${editMessageId}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({ text })
        });

        editMessageId = null;
        replyTo = null;
        clearReplyPreview();

        return;
    }

    // ============================
    // 2. REPLY (ОТВЕТ)
    // ============================
    let finalText = text;
    if (replyTo) {
        finalText = `↪ Ответ на: "${replyTo.text || ''}"\n` + text;
    }

    // ============================
    // 3. ОТПРАВКА ЧЕРЕЗ WEBSOCKET
    // ============================
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ text: finalText }));
    }

    // ============================
    // 4. FALLBACK: ОТПРАВКА ЧЕРЕЗ REST
    // ============================
    else {
        await fetch(API_URL + "/messages", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({
                chat_id: currentChatId,
                text: finalText
            })
        });
    }

    // ============================
    // 5. СБРОС СОСТОЯНИЙ
    // ============================
    replyTo = null;
    clearReplyPreview();

    const input = document.getElementById("messageInput");
    if (input) input.value = "";
}


// =========================
// WEBSOCKET
// =========================

function connectWS(chatId) {
    if (ws) {
        ws.onclose = null;
        ws.close();
    }

    ws = new WebSocket(`ws://localhost:8000/ws/chat/${chatId}?token=${token}`);

    ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);

        if (msg.typing !== undefined) {
            const indicator = document.getElementById("typingIndicator");
            if (indicator && msg.user_id !== getUserId()) {
                indicator.textContent = msg.typing ? "печатает..." : "";
            }
            return;
        }

        if (msg.type === "delete") {
            const bubble = document.querySelector(`.message-bubble[data-id="${msg.id}"]`);
            if (bubble) bubble.remove();
            return;
        }

        if (msg.type === "edit") {
            const bubble = document.querySelector(`.message-bubble[data-id="${msg.id}"]`);
            if (bubble) {
                const textEl = bubble.querySelector(".message-text");
                if (textEl) {
                    textEl.textContent = msg.text;
                    bubble.classList.add("message-edited");
                }
            }
            return;
        }
    // спец-событие: удаление сообщения
    if (msg.type === "delete") {
        const bubble = document.querySelector(`.message-bubble[data-id="${msg.id}"]`);
        if (bubble) bubble.remove();
        return;
    }

    // спец-событие: редактирование сообщения
    if (msg.type === "edit") {
        const bubble = document.querySelector(`.message-bubble[data-id="${msg.id}"]`);
        if (bubble) {
            const textEl = bubble.querySelector(".message-text");
            if (textEl) {
                textEl.textContent = msg.text;
                bubble.classList.add("message-edited");
            }
        }
        return;
    }

    console.log("WS MESSAGE:", msg);
    appendMessage(msg);
};

}

function appendMessage(msg) {
    const body = document.getElementById("chatBody");

    const row = document.createElement("div");
    row.className = "message-row " + (msg.user_id === getUserId() ? "me" : "them");

    const wrap = document.createElement("div");
    wrap.className = "bubble-wrap";

    const bubble = document.createElement("div");
    bubble.className = "message-bubble " + (msg.user_id === getUserId() ? "me" : "them");
    bubble.dataset.id = msg.id; // ← важно для ПКМ, удаления, редактирования

    // ============================
    // 1. РЕЖИМ ВЫДЕЛЕНИЯ
    // ============================
    bubble.addEventListener("click", (e) => {
        if (!selectionMode) return;
        bubble.classList.toggle("selected");

        const id = bubble.dataset.id;
        if (bubble.classList.contains("selected")) {
            selectedMessages.add(id);
        } else {
            selectedMessages.delete(id);
        }
    });

    // ============================
    // 2. ФАЙЛЫ (картинки / документы)
    // ============================
    if (msg.image_url) {
        const fileUrl = "http://localhost:8000" + msg.image_url;

        // === Изображение ===
        if (msg.file_type && msg.file_type.startsWith("image/")) {
            const img = document.createElement("img");
            img.src = fileUrl;
            img.className = "message-image";

            // Открытие в большом размере
            img.onclick = () => {
                const modal = document.getElementById("imageModal");
                const modalImg = document.getElementById("imageModalImg");
                modal.style.display = "block";
                modalImg.src = img.src;
            };

            bubble.appendChild(img);

            // Кнопка "Скачать"
            const downloadBtn = document.createElement("a");
            downloadBtn.href = fileUrl;
            downloadBtn.download = msg.text || "image";
            downloadBtn.textContent = "Скачать";
            downloadBtn.className = "download-btn";
            bubble.appendChild(downloadBtn);

        } else {
            // === Документы ===
            const link = document.createElement("a");
            link.className = "file-link";
            link.textContent = msg.text || "Файл";
            link.target = "_blank";

            // DOCX → Google Docs Viewer
            if (msg.file_type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
                link.href = "https://docs.google.com/viewer?url=" + encodeURIComponent(fileUrl);
            } else {
                link.href = fileUrl;
            }

            bubble.appendChild(link);
        }
    }

    // ============================
    // 3. ТЕКСТ (если нет файла)
    // ============================
    if (msg.text && !msg.image_url) {
        const textNode = document.createElement("div");
        textNode.className = "message-text";
        textNode.textContent = msg.text;
        bubble.appendChild(textNode);
    }

    // ============================
    // 4. МЕТА (время)
    // ============================
    const meta = document.createElement("div");
    meta.className = "message-meta";
    meta.textContent = new Date(msg.created_at).toLocaleTimeString();

    wrap.appendChild(bubble);
    wrap.appendChild(meta);
    row.appendChild(wrap);
    body.appendChild(row);

    body.scrollTop = body.scrollHeight;
}


// =========================
// HELPERS
// =========================

function getUserId() {
    try {
        const payload = JSON.parse(atob(token.split(".")[1]));
        return Number(payload.sub);
    } catch {
        return null;
    }
}

function generateColorFromName(name) {
    const palette = [
        "#4cc9f0",
        "#4361ee",
        "#7209b7",
        "#f72585",
        "#3a86ff",
        "#8338ec",
        "#ff006e"
    ];

    let hash = 0;
    for (let i = 0; i < name.length; i++) {
        hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }

    return palette[Math.abs(hash) % palette.length];
}

// =========================
// SEND BUTTON
// =========================

document.getElementById("sendBtn").onclick = () => {
    const input = document.getElementById("messageInput");
    const text = input.value.trim();
    if (text) {
        sendMessage(text);
        input.value = "";
    }
};

// =========================
// TYPING INDICATOR
// =========================

let typingTimeout;

document.getElementById("messageInput").oninput = () => {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ typing: true }));
    }

    clearTimeout(typingTimeout);
    typingTimeout = setTimeout(() => {
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ typing: false }));
        }
    }, 1200);
};

// ===========================
// CREATE GROUP CHAT
// ===========================

async function createChat() {
    const title = prompt("Введите название группы:");
    if (!title) return;

    const memberIdsRaw = prompt("Введите ID участников через запятую (например: 2,3,5):");
    const memberIds = memberIdsRaw
        ? memberIdsRaw.split(",").map(x => Number(x.trim())).filter(x => !isNaN(x))
        : [];

    const res = await fetch(API_URL + "/chats", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify({
            title,
            member_ids: memberIds
        })
    });

    if (!res.ok) {
        alert("Ошибка при создании группы");
        return;
    }

    await loadChats();
}

// ===========================
// UNIFIED SEARCH
// ===========================

document.getElementById("userSearch").oninput = async (e) => {
    const q = e.target.value.trim();
    const box = document.getElementById("searchResults");

    if (!q) {
        box.innerHTML = "";
        return;
    }

    const res = await fetch(API_URL + "/search?q=" + q, {
        headers: { "Authorization": "Bearer " + token }
    });
    const results = await res.json();

    box.innerHTML = "";

    results.forEach(item => {
        const div = document.createElement("div");
        div.className = "chat-item";

        // Унифицированное название
        const title = item.type === "user"
            ? item.username
            : (item.title || "Группа");

        // Бейдж типа
        const badge = item.type === "group" ? "👥" : "👤";

        div.innerHTML = `
            <div class="avatar" style="--avatar-color:${generateColorFromName(title)}">
                ${title[0].toUpperCase()}
                <div class="avatar-badge">${badge}</div>
            </div>
            <div class="chat-main">
                <div class="chat-name">${title}</div>
            </div>
        `;

        // Логика клика НЕ меняется
        if (item.type === "user") {
            div.onclick = () => startPrivateChat(item.id, item.username);
        } else {
            div.onclick = () => openChat(item.id, item.title);
        }

        box.appendChild(div);
    });
};

// ===========================
// PRIVATE CHAT
// ===========================

async function startPrivateChat(otherUserId, otherUsername) {
    const res = await fetch(`${API_URL}/chats/private?other_user_id=${otherUserId}`, {
        method: "POST",
        headers: { "Authorization": "Bearer " + token }
    });

    const data = await res.json();

    if (res.ok) {
        await loadChats();
        // backend почти наверняка возвращает { id: ..., title: ... }
        openChat(data.id, otherUsername);
    } else {
        console.error(data);
    }
}

// ===========================
// PROFILE
// ===========================

function loadProfile() {
    fetch(API_URL + "/me", {
        headers: { "Authorization": "Bearer " + token }
    })
        .then(r => r.json())
        .then(user => {
            document.getElementById("profileName").textContent = user.username;
            document.getElementById("profileAvatar").textContent = user.username[0].toUpperCase();
        });
}

// ===========================
// CHAT SEARCH (SAFE VERSION)
// ===========================

const chatSearchBtn = document.getElementById("chatSearchBtn");
const chatSearchInput = document.getElementById("chatSearchInput");

if (chatSearchBtn && chatSearchInput) {

    chatSearchBtn.onclick = () => {
        chatSearchInput.style.display =
            chatSearchInput.style.display === "none" ? "block" : "none";
        chatSearchInput.focus();
    };

    chatSearchInput.oninput = (e) => {
        const q = e.target.value.toLowerCase();

        document.querySelectorAll(".message-bubble").forEach(msg => {
            const text = msg.innerText.toLowerCase();
            msg.classList.toggle("highlight", q && text.includes(q));
        });
    };

    let searchResults = [];
let searchIndex = 0;

document.getElementById("chatSearchInput").oninput = (e) => {
    const q = e.target.value.toLowerCase();

    // Сбрасываем подсветку пузырей
    document.querySelectorAll(".message-bubble").forEach(msg => {
        msg.classList.remove("highlight", "active-highlight");
        msg.innerHTML = msg.innerHTML.replace(/<\/?span[^>]*>/g, ""); // убираем старые подсветки текста
    });

    if (!q) {
        document.getElementById("searchNav").style.display = "none";
        return;
    }

    // Находим совпадения
    searchResults = Array.from(document.querySelectorAll(".message-bubble"))
        .filter(msg => msg.innerText.toLowerCase().includes(q));

    // Подсвечиваем совпадения
    searchResults.forEach(msg => {
        const text = msg.innerHTML;
        const regex = new RegExp(`(${q})`, "gi");
        msg.innerHTML = text.replace(regex, `<span class="highlight-text">$1</span>`);
        msg.classList.add("highlight");
    });

    if (searchResults.length === 0) {
        document.getElementById("searchNav").style.display = "none";
        return;
    }

    document.getElementById("searchNav").style.display = "flex";

    searchIndex = 0;
    updateSearchCounter();
    highlightActive();
};

function updateSearchCounter() {
    document.getElementById("searchCounter").textContent =
        `${searchIndex + 1} / ${searchResults.length}`;
}

function highlightActive() {
    searchResults.forEach(msg => {
        msg.classList.remove("active-highlight");
        msg.innerHTML = msg.innerHTML.replace(/active-highlight-text/g, "highlight-text");
    });

    const msg = searchResults[searchIndex];
    msg.classList.add("active-highlight");

    // выделяем активный текст
    msg.innerHTML = msg.innerHTML.replace(/highlight-text/g, "active-highlight-text");

    msg.scrollIntoView({ behavior: "smooth", block: "center" });
}

document.getElementById("searchNext").onclick = () => {
    if (searchResults.length === 0) return;
    searchIndex = (searchIndex + 1) % searchResults.length;
    updateSearchCounter();
    highlightActive();
};

document.getElementById("searchPrev").onclick = () => {
    if (searchResults.length === 0) return;
    searchIndex = (searchIndex - 1 + searchResults.length) % searchResults.length;
    updateSearchCounter();
    highlightActive();
};

// ===========================
// Логика закрепления
// ===========================
function togglePinChat(chatId) {
    if (pinnedChats.includes(chatId)) {
        pinnedChats = pinnedChats.filter(id => id !== chatId);
    } else {
        pinnedChats.push(chatId);
    }
    localStorage.setItem("pinnedChats", JSON.stringify(pinnedChats));
    loadChats();
}

document.getElementById("pinChatBtn").onclick = () => {
    if (currentChatId) togglePinChat(currentChatId);
};

const chatMenuBtn = document.getElementById("chatMenuBtn");
const chatMenu = document.getElementById("chatMenu");

chatMenuBtn.onclick = () => {
    chatMenu.style.display = chatMenu.style.display === "none" ? "block" : "none";
};

// Закрытие меню при клике вне
document.addEventListener("click", (e) => {
    if (!chatMenu.contains(e.target) && e.target !== chatMenuBtn) {
        chatMenu.style.display = "none";
    }
});

document.getElementById("chatInfoBtn").onclick = () => {
    alert("Информация о чате (в разработке)");
};

document.getElementById("chatMembersBtn").onclick = () => {
    alert("Список участников (в разработке)");
};

document.getElementById("chatAddMemberBtn").onclick = () => {
    alert("Добавление участника (в разработке)");
};

document.getElementById("chatLeaveBtn").onclick = () => {
    alert("Покинуть чат (в разработке)");
};

document.getElementById("chatDeleteBtn").onclick = () => {
    alert("Удаление чата (в разработке)");
};

const emojiList = [
    "😀","😁","😂","🤣","😅","😊","😍","😘","😎","😢","😭","😡",
    "👍","👎","🙏","👏","🔥","⭐","💯","❤️","💔","🎉","✨","⚡"
];

const emojiPanel = document.getElementById("emojiPanel");
emojiPanel.innerHTML = emojiList.map(e => `<span>${e}</span>`).join("");

const emojiBtn = document.getElementById("emojiBtn");

emojiBtn.onclick = () => {
    emojiPanel.style.display =
        emojiPanel.style.display === "none" ? "grid" : "none";
};

emojiPanel.onclick = (e) => {
    if (e.target.tagName === "SPAN") {
        const input = document.getElementById("messageInput");
        input.value += e.target.textContent;
        input.focus();
    }
};

document.addEventListener("click", (e) => {
    if (!emojiPanel.contains(e.target) && e.target !== emojiBtn) {
        emojiPanel.style.display = "none";
    }
});


//=================
//отправка файлов
//=================
const attachBtn = document.getElementById("attachBtn");
const fileInput = document.getElementById("fileInput");

attachBtn.onclick = () => {
    fileInput.click();
};

fileInput.onchange = () => {
    const file = fileInput.files[0];
    if (!file) return;

    uploadFileWithProgress(file);
};

function uploadFileWithProgress(file) {
    const xhr = new XMLHttpRequest();
    const formData = new FormData();

    formData.append("file", file);

    // создаём временное сообщение "загружается..."
    const tempId = "upload-" + Date.now();
    showUploadingMessage(file.name, tempId);

    xhr.upload.onprogress = (e) => {
        if (e.lengthComputable) {
            const percent = Math.round((e.loaded / e.total) * 100);
            updateUploadingProgress(tempId, percent);
        }
    };

    xhr.onreadystatechange = () => {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                const res = JSON.parse(xhr.responseText);

                // ============================
                // 1. Формируем WS-пакет
                // ============================
                const payload = {
                    file_url: res.url,
                    file_name: res.filename,
                    file_type: res.content_type,
                    chat_id: currentChatId
                };

                // ============================
                // 2. Если reply → добавляем reply-текст
                // ============================
                if (replyTo) {
                    payload.text = `↪ Ответ на: "${replyTo.text || ''}"`;
                    replyTo = null;
                    clearReplyPreview();
                }

                // ============================
                // 3. Отправка через WebSocket
                // ============================
                if (ws && ws.readyState === WebSocket.OPEN) {
                    ws.send(JSON.stringify(payload));
                } else {
                    console.warn("WS закрыт, файл не отправлен");
                }

                finishUploadingMessage(tempId);
            } else {
                failUploadingMessage(tempId);
            }
        }
    };

    xhr.open("POST", `${API_URL}/upload`, true);
    xhr.setRequestHeader("Authorization", "Bearer " + token);
    xhr.send(formData);
}


function showUploadingMessage(filename, tempId) {
    const body = document.getElementById("chatBody");

    const row = document.createElement("div");
    row.className = "message-row me";
    row.dataset.tempId = tempId;

    const wrap = document.createElement("div");
    wrap.className = "bubble-wrap";

    const bubble = document.createElement("div");
    bubble.className = "message-bubble me uploading";

    const nameDiv = document.createElement("div");
    nameDiv.textContent = filename;

    const progress = document.createElement("div");
    progress.className = "upload-progress";
    progress.textContent = "0%";

    bubble.appendChild(nameDiv);
    bubble.appendChild(progress);
    wrap.appendChild(bubble);
    row.appendChild(wrap);
    body.appendChild(row);

    body.scrollTop = body.scrollHeight;
}

function updateUploadingProgress(tempId, percent) {
    const row = document.querySelector(`.message-row[data-temp-id="${tempId}"]`);
    if (!row) return;
    const progress = row.querySelector(".upload-progress");
    if (progress) progress.textContent = percent + "%";
}

function finishUploadingMessage(tempId) {
    const row = document.querySelector(`.message-row[data-temp-id="${tempId}"]`);
    if (row) row.remove();
}

function failUploadingMessage(tempId) {
    const row = document.querySelector(`.message-row[data-temp-id="${tempId}"]`);
    if (!row) return;
    const progress = row.querySelector(".upload-progress");
    if (progress) progress.textContent = "Ошибка загрузки";
}

// =========================
// CONTEXT MENU (ПКМ)
// =========================

document.addEventListener("contextmenu", (e) => {
    const bubble = e.target.closest(".message-bubble");
    if (!bubble) return;

    e.preventDefault();

    const msgId = bubble.dataset.id;
    const msgText = bubble.querySelector(".message-text")?.innerText || "";

    showContextMenu(e.pageX, e.pageY, msgId, msgText);
});

function showContextMenu(x, y, msgId, msgText) {
    removeContextMenu();

    const menu = document.createElement("div");
    menu.className = "context-menu neon-menu";
    menu.style.top = y + "px";
    menu.style.left = x + "px";

    const addItem = (label, handler) => {
        const item = document.createElement("div");
        item.className = "context-item neon-item";
        item.textContent = label;
        item.onclick = () => {
            handler();
            removeContextMenu();
        };
        menu.appendChild(item);
    };

    // Ответить
    addItem("Ответить", () => {
        replyTo = { id: msgId, text: msgText };
        showReplyPreview(msgText);
    });

    // Редактировать
    addItem("Редактировать", () => {
        const input = document.getElementById("messageInput");
        input.value = msgText;
        editMessageId = msgId;
        showReplyPreview("Редактирование сообщения");
    });

    // Переслать
    addItem("Переслать", () => {
        const targetChatId = prompt("ID чата для пересылки:");
        if (!targetChatId) return;

        fetch(`http://localhost:8000/messages/${msgId}/forward`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({ target_chat_id: Number(targetChatId) })
        });
    });

    // Удалить
    addItem("Удалить", () => {
        fetch(`http://localhost:8000/messages/${msgId}`, {
            method: "DELETE",
            headers: {
                "Authorization": "Bearer " + token
            }
        });
    });

    // Режим выбора
    addItem(selectionMode ? "Выйти из выбора" : "Выбрать сообщения", () => {
        selectionMode = !selectionMode;

        if (!selectionMode) {
            selectedMessages.clear();
            document.querySelectorAll(".message-bubble.selected")
                .forEach(b => b.classList.remove("selected"));
            hideSelectionBar();
        } else {
            showSelectionBar();
        }
    });

    document.body.appendChild(menu);
}

function removeContextMenu() {
    const old = document.querySelector(".context-menu");
    if (old) old.remove();
}

document.addEventListener("click", (e) => {
    if (!e.target.closest(".context-menu")) removeContextMenu();
});


// =========================
// SELECTION BAR
// =========================

function showSelectionBar() {
    const bar = document.getElementById("selectionBar");
    if (bar) bar.style.display = "flex";
}

function hideSelectionBar() {
    const bar = document.getElementById("selectionBar");
    if (bar) bar.style.display = "none";
}

function deleteSelectedMessages() {
    selectedMessages.forEach(id => {
        fetch(`http://localhost:8000/messages/${id}`, {
            method: "DELETE",
            headers: {
                "Authorization": "Bearer " + token
            }
        });
    });

    selectedMessages.clear();
    hideSelectionBar();
    selectionMode = false;
}

function forwardSelectedMessages() {
    const targetChatId = prompt("ID чата для пересылки:");
    if (!targetChatId) return;

    selectedMessages.forEach(id => {
        fetch(`http://localhost:8000/messages/${id}/forward`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({ target_chat_id: Number(targetChatId) })
        });
    });

    selectedMessages.clear();
    hideSelectionBar();
    selectionMode = false;
}

document.addEventListener("contextmenu", (e) => {
    const bubble = e.target.closest(".message-bubble");
    if (!bubble) return;

    e.preventDefault();

    const msgId = bubble.dataset.id;
    const msgText = bubble.querySelector(".message-text")?.innerText || "";

    showContextMenu(e.pageX, e.pageY, msgId, msgText);
});

function showContextMenu(x, y, msgId, msgText) {
    removeContextMenu();

    const menu = document.createElement("div");
    menu.className = "context-menu";
    menu.style.top = y + "px";
    menu.style.left = x + "px";

    const addItem = (label, handler) => {
        const item = document.createElement("div");
        item.className = "context-item";
        item.textContent = label;
        item.onclick = () => {
            handler();
            removeContextMenu();
        };
        menu.appendChild(item);
    };

    addItem("Ответить", () => {
        replyTo = { id: msgId, text: msgText };
        showReplyPreview(msgText);
    });

    addItem("Редактировать", () => {
        const input = document.getElementById("messageInput");
        input.value = msgText;
        editMessageId = msgId;
        showReplyPreview("Редактирование сообщения");
    });

    addItem("Переслать", () => {
        const targetChatId = prompt("ID чата:");
        if (!targetChatId) return;

        fetch(`http://localhost:8000/messages/${msgId}/forward`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify({ target_chat_id: Number(targetChatId) })
        });
    });

    addItem("Удалить", () => {
        fetch(`http://localhost:8000/messages/${msgId}`, {
            method: "DELETE",
            headers: {
                "Authorization": "Bearer " + token
            }
        });
    });

    addItem(selectionMode ? "Выйти из выбора" : "Выбрать сообщения", () => {
        selectionMode = !selectionMode;

        if (!selectionMode) {
            selectedMessages.clear();
            document.querySelectorAll(".message-bubble.selected")
                .forEach(b => b.classList.remove("selected"));
            hideSelectionBar();
        } else {
            showSelectionBar();
        }
    });

    document.body.appendChild(menu);
}

function removeContextMenu() {
    const old = document.querySelector(".context-menu");
    if (old) old.remove();
}

document.addEventListener("click", (e) => {
    if (!e.target.closest(".context-menu")) removeContextMenu();
});



}

loadChats();
loadProfile();



